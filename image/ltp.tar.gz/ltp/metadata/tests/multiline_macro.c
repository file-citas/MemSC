#define TEST_VARIANTS \
	10

static struct tst_test test = {
	.test_variants = TEST_VARIANTS,
};
