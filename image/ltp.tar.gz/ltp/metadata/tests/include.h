#define TEST_VARIANTS 10

static struct variants[] = {
	{.bar = 10},
	{.bar = 11},
	{.bar = 12}
};
