static struct tst_test test = {
	.tags = (const struct tst_tag[]) {
		{"tag-name-1", "tag-value-1"},
		{"tag-name-2", "tag-value-2"},
		{}
	}
};
