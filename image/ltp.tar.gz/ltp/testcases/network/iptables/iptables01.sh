#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (c) 2018-2019 Oracle and/or its affiliates. All Rights Reserved.

use_iptables=1

. iptables_lib.sh

tst_run
