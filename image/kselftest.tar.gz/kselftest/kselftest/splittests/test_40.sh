#!/bin/sh
BASE_DIR=$(realpath $(dirname $0))
cd $BASE_DIR
ROOT=$PWD
if [ "$1" = "--summary" ]; then
  OUTPUT=$BASE_DIR/output.log
  cat /dev/null > $OUTPUT
else
  OUTPUT=/dev/stdout
fi
export KSFT_TAP_LEVEL=1
export skip=4
cd $ROOT
echo ; echo TAP version 13
echo Running tests in timers
echo ========================================
[ -w /dev/kmsg ] && echo "kselftest: Running tests in timers" >> /dev/kmsg
cd timers
echo selftests: timers: posix_timers
(./posix_timers >> $OUTPUT 2>&1 && echo "ok 1..1 selftests: timers: posix_timers [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..1 selftests: timers: posix_timers [SKIP]"; else echo "not ok 1..1 selftests: timers: posix_timers [FAIL]"; fi;)
echo selftests: timers: nanosleep
(./nanosleep >> $OUTPUT 2>&1 && echo "ok 1..2 selftests: timers: nanosleep [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..2 selftests: timers: nanosleep [SKIP]"; else echo "not ok 1..2 selftests: timers: nanosleep [FAIL]"; fi;)
echo selftests: timers: nsleep-lat
(./nsleep-lat >> $OUTPUT 2>&1 && echo "ok 1..3 selftests: timers: nsleep-lat [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..3 selftests: timers: nsleep-lat [SKIP]"; else echo "not ok 1..3 selftests: timers: nsleep-lat [FAIL]"; fi;)
echo selftests: timers: set-timer-lat
(./set-timer-lat >> $OUTPUT 2>&1 && echo "ok 1..4 selftests: timers: set-timer-lat [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..4 selftests: timers: set-timer-lat [SKIP]"; else echo "not ok 1..4 selftests: timers: set-timer-lat [FAIL]"; fi;)
echo selftests: timers: mqueue-lat
(./mqueue-lat >> $OUTPUT 2>&1 && echo "ok 1..5 selftests: timers: mqueue-lat [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..5 selftests: timers: mqueue-lat [SKIP]"; else echo "not ok 1..5 selftests: timers: mqueue-lat [FAIL]"; fi;)
echo selftests: timers: inconsistency-check
(./inconsistency-check >> $OUTPUT 2>&1 && echo "ok 1..6 selftests: timers: inconsistency-check [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..6 selftests: timers: inconsistency-check [SKIP]"; else echo "not ok 1..6 selftests: timers: inconsistency-check [FAIL]"; fi;)
echo selftests: timers: raw_skew
(./raw_skew >> $OUTPUT 2>&1 && echo "ok 1..7 selftests: timers: raw_skew [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..7 selftests: timers: raw_skew [SKIP]"; else echo "not ok 1..7 selftests: timers: raw_skew [FAIL]"; fi;)
echo selftests: timers: threadtest
(./threadtest >> $OUTPUT 2>&1 && echo "ok 1..8 selftests: timers: threadtest [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..8 selftests: timers: threadtest [SKIP]"; else echo "not ok 1..8 selftests: timers: threadtest [FAIL]"; fi;)
echo selftests: timers: rtcpie
(./rtcpie >> $OUTPUT 2>&1 && echo "ok 1..9 selftests: timers: rtcpie [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..9 selftests: timers: rtcpie [SKIP]"; else echo "not ok 1..9 selftests: timers: rtcpie [FAIL]"; fi;)
cd $ROOT
