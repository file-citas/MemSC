#!/bin/sh
BASE_DIR=$(realpath $(dirname $0))
cd $BASE_DIR
ROOT=$PWD
if [ "$1" = "--summary" ]; then
  OUTPUT=$BASE_DIR/output.log
  cat /dev/null > $OUTPUT
else
  OUTPUT=/dev/stdout
fi
export KSFT_TAP_LEVEL=1
export skip=4
cd $ROOT
echo ; echo TAP version 13
echo Running tests in proc
echo ========================================
[ -w /dev/kmsg ] && echo "kselftest: Running tests in proc" >> /dev/kmsg
cd proc
echo selftests: proc: fd-001-lookup
(./fd-001-lookup >> $OUTPUT 2>&1 && echo "ok 1..1 selftests: proc: fd-001-lookup [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..1 selftests: proc: fd-001-lookup [SKIP]"; else echo "not ok 1..1 selftests: proc: fd-001-lookup [FAIL]"; fi;)
echo selftests: proc: fd-002-posix-eq
(./fd-002-posix-eq >> $OUTPUT 2>&1 && echo "ok 1..2 selftests: proc: fd-002-posix-eq [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..2 selftests: proc: fd-002-posix-eq [SKIP]"; else echo "not ok 1..2 selftests: proc: fd-002-posix-eq [FAIL]"; fi;)
echo selftests: proc: fd-003-kthread
(./fd-003-kthread >> $OUTPUT 2>&1 && echo "ok 1..3 selftests: proc: fd-003-kthread [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..3 selftests: proc: fd-003-kthread [SKIP]"; else echo "not ok 1..3 selftests: proc: fd-003-kthread [FAIL]"; fi;)
echo selftests: proc: proc-loadavg-001
(./proc-loadavg-001 >> $OUTPUT 2>&1 && echo "ok 1..4 selftests: proc: proc-loadavg-001 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..4 selftests: proc: proc-loadavg-001 [SKIP]"; else echo "not ok 1..4 selftests: proc: proc-loadavg-001 [FAIL]"; fi;)
echo selftests: proc: proc-self-map-files-001
(./proc-self-map-files-001 >> $OUTPUT 2>&1 && echo "ok 1..5 selftests: proc: proc-self-map-files-001 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..5 selftests: proc: proc-self-map-files-001 [SKIP]"; else echo "not ok 1..5 selftests: proc: proc-self-map-files-001 [FAIL]"; fi;)
echo selftests: proc: proc-self-map-files-002
(./proc-self-map-files-002 >> $OUTPUT 2>&1 && echo "ok 1..6 selftests: proc: proc-self-map-files-002 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..6 selftests: proc: proc-self-map-files-002 [SKIP]"; else echo "not ok 1..6 selftests: proc: proc-self-map-files-002 [FAIL]"; fi;)
echo selftests: proc: proc-self-syscall
(./proc-self-syscall >> $OUTPUT 2>&1 && echo "ok 1..7 selftests: proc: proc-self-syscall [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..7 selftests: proc: proc-self-syscall [SKIP]"; else echo "not ok 1..7 selftests: proc: proc-self-syscall [FAIL]"; fi;)
echo selftests: proc: proc-self-wchan
(./proc-self-wchan >> $OUTPUT 2>&1 && echo "ok 1..8 selftests: proc: proc-self-wchan [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..8 selftests: proc: proc-self-wchan [SKIP]"; else echo "not ok 1..8 selftests: proc: proc-self-wchan [FAIL]"; fi;)
echo selftests: proc: proc-uptime-001
(./proc-uptime-001 >> $OUTPUT 2>&1 && echo "ok 1..9 selftests: proc: proc-uptime-001 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..9 selftests: proc: proc-uptime-001 [SKIP]"; else echo "not ok 1..9 selftests: proc: proc-uptime-001 [FAIL]"; fi;)
echo selftests: proc: proc-uptime-002
(./proc-uptime-002 >> $OUTPUT 2>&1 && echo "ok 1..10 selftests: proc: proc-uptime-002 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..10 selftests: proc: proc-uptime-002 [SKIP]"; else echo "not ok 1..10 selftests: proc: proc-uptime-002 [FAIL]"; fi;)
echo selftests: proc: read
(./read >> $OUTPUT 2>&1 && echo "ok 1..11 selftests: proc: read [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..11 selftests: proc: read [SKIP]"; else echo "not ok 1..11 selftests: proc: read [FAIL]"; fi;)
echo selftests: proc: self
(./self >> $OUTPUT 2>&1 && echo "ok 1..12 selftests: proc: self [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..12 selftests: proc: self [SKIP]"; else echo "not ok 1..12 selftests: proc: self [FAIL]"; fi;)
echo selftests: proc: thread-self
(./thread-self >> $OUTPUT 2>&1 && echo "ok 1..13 selftests: proc: thread-self [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..13 selftests: proc: thread-self [SKIP]"; else echo "not ok 1..13 selftests: proc: thread-self [FAIL]"; fi;)
cd $ROOT
