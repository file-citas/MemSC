#!/bin/sh
BASE_DIR=$(realpath $(dirname $0))
cd $BASE_DIR
ROOT=$PWD
if [ "$1" = "--summary" ]; then
  OUTPUT=$BASE_DIR/output.log
  cat /dev/null > $OUTPUT
else
  OUTPUT=/dev/stdout
fi
export KSFT_TAP_LEVEL=1
export skip=4
cd $ROOT
echo ; echo TAP version 13
echo Running tests in kvm
echo ========================================
[ -w /dev/kmsg ] && echo "kselftest: Running tests in kvm" >> /dev/kmsg
cd kvm
echo selftests: kvm: platform_info_test
echo "selftests: kvm: platform_info_test: Warning: file platform_info_test is not executable, correct this."
echo "not ok 1..1 selftests: kvm: platform_info_test [FAIL]"
echo selftests: kvm: set_sregs_test
echo "selftests: kvm: set_sregs_test: Warning: file set_sregs_test is not executable, correct this."
echo "not ok 1..2 selftests: kvm: set_sregs_test [FAIL]"
echo selftests: kvm: sync_regs_test
echo "selftests: kvm: sync_regs_test: Warning: file sync_regs_test is not executable, correct this."
echo "not ok 1..3 selftests: kvm: sync_regs_test [FAIL]"
echo selftests: kvm: vmx_tsc_adjust_test
echo "selftests: kvm: vmx_tsc_adjust_test: Warning: file vmx_tsc_adjust_test is not executable, correct this."
echo "not ok 1..4 selftests: kvm: vmx_tsc_adjust_test [FAIL]"
echo selftests: kvm: cr4_cpuid_sync_test
echo "selftests: kvm: cr4_cpuid_sync_test: Warning: file cr4_cpuid_sync_test is not executable, correct this."
echo "not ok 1..5 selftests: kvm: cr4_cpuid_sync_test [FAIL]"
echo selftests: kvm: state_test
echo "selftests: kvm: state_test: Warning: file state_test is not executable, correct this."
echo "not ok 1..6 selftests: kvm: state_test [FAIL]"
echo selftests: kvm: evmcs_test
echo "selftests: kvm: evmcs_test: Warning: file evmcs_test is not executable, correct this."
echo "not ok 1..7 selftests: kvm: evmcs_test [FAIL]"
echo selftests: kvm: dirty_log_test
echo "selftests: kvm: dirty_log_test: Warning: file dirty_log_test is not executable, correct this."
echo "not ok 1..8 selftests: kvm: dirty_log_test [FAIL]"
cd $ROOT
