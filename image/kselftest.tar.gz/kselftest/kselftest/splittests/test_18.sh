#!/bin/sh
BASE_DIR=$(realpath $(dirname $0))
cd $BASE_DIR
ROOT=$PWD
if [ "$1" = "--summary" ]; then
  OUTPUT=$BASE_DIR/output.log
  cat /dev/null > $OUTPUT
else
  OUTPUT=/dev/stdout
fi
export KSFT_TAP_LEVEL=1
export skip=4
cd $ROOT
echo ; echo TAP version 13
echo Running tests in firmware
echo ========================================
[ -w /dev/kmsg ] && echo "kselftest: Running tests in firmware" >> /dev/kmsg
cd firmware
echo selftests: firmware: fw_run_tests.sh
(./fw_run_tests.sh >> $OUTPUT 2>&1 && echo "ok 1..1 selftests: firmware: fw_run_tests.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..1 selftests: firmware: fw_run_tests.sh [SKIP]"; else echo "not ok 1..1 selftests: firmware: fw_run_tests.sh [FAIL]"; fi;)
cd $ROOT
