#!/bin/sh
BASE_DIR=$(realpath $(dirname $0))
cd $BASE_DIR
ROOT=$PWD
if [ "$1" = "--summary" ]; then
  OUTPUT=$BASE_DIR/output.log
  cat /dev/null > $OUTPUT
else
  OUTPUT=/dev/stdout
fi
export KSFT_TAP_LEVEL=1
export skip=4
cd $ROOT
echo ; echo TAP version 13
echo Running tests in mqueue
echo ========================================
[ -w /dev/kmsg ] && echo "kselftest: Running tests in mqueue" >> /dev/kmsg
cd mqueue
echo selftests: mqueue: mq_open_tests
echo "selftests: mqueue: mq_open_tests: Warning: file mq_open_tests is not executable, correct this."
echo "not ok 1..1 selftests: mqueue: mq_open_tests [FAIL]"
echo selftests: mqueue: mq_perf_tests
echo "selftests: mqueue: mq_perf_tests: Warning: file mq_perf_tests is not executable, correct this."
echo "not ok 1..2 selftests: mqueue: mq_perf_tests [FAIL]"
cd $ROOT
