#!/bin/sh
BASE_DIR=$(realpath $(dirname $0))
cd $BASE_DIR
ROOT=$PWD
if [ "$1" = "--summary" ]; then
  OUTPUT=$BASE_DIR/output.log
  cat /dev/null > $OUTPUT
else
  OUTPUT=/dev/stdout
fi
export KSFT_TAP_LEVEL=1
export skip=4
cd $ROOT
echo ; echo TAP version 13
echo Running tests in seccomp
echo ========================================
[ -w /dev/kmsg ] && echo "kselftest: Running tests in seccomp" >> /dev/kmsg
cd seccomp
echo selftests: seccomp: seccomp_bpf
(./seccomp_bpf >> $OUTPUT 2>&1 && echo "ok 1..1 selftests: seccomp: seccomp_bpf [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..1 selftests: seccomp: seccomp_bpf [SKIP]"; else echo "not ok 1..1 selftests: seccomp: seccomp_bpf [FAIL]"; fi;)
echo selftests: seccomp: seccomp_benchmark
(./seccomp_benchmark >> $OUTPUT 2>&1 && echo "ok 1..2 selftests: seccomp: seccomp_benchmark [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..2 selftests: seccomp: seccomp_benchmark [SKIP]"; else echo "not ok 1..2 selftests: seccomp: seccomp_benchmark [FAIL]"; fi;)
cd $ROOT
