#!/bin/sh
BASE_DIR=$(realpath $(dirname $0))
cd $BASE_DIR
ROOT=$PWD
if [ "$1" = "--summary" ]; then
  OUTPUT=$BASE_DIR/output.log
  cat /dev/null > $OUTPUT
else
  OUTPUT=/dev/stdout
fi
export KSFT_TAP_LEVEL=1
export skip=4
cd $ROOT
echo ; echo TAP version 13
echo Running tests in bpf
echo ========================================
[ -w /dev/kmsg ] && echo "kselftest: Running tests in bpf" >> /dev/kmsg
cd bpf
echo selftests: bpf: test_verifier
(./test_verifier >> $OUTPUT 2>&1 && echo "ok 1..1 selftests: bpf: test_verifier [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..1 selftests: bpf: test_verifier [SKIP]"; else echo "not ok 1..1 selftests: bpf: test_verifier [FAIL]"; fi;)
echo selftests: bpf: test_tag
(./test_tag >> $OUTPUT 2>&1 && echo "ok 1..2 selftests: bpf: test_tag [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..2 selftests: bpf: test_tag [SKIP]"; else echo "not ok 1..2 selftests: bpf: test_tag [FAIL]"; fi;)
echo selftests: bpf: test_maps
(./test_maps >> $OUTPUT 2>&1 && echo "ok 1..3 selftests: bpf: test_maps [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..3 selftests: bpf: test_maps [SKIP]"; else echo "not ok 1..3 selftests: bpf: test_maps [FAIL]"; fi;)
echo selftests: bpf: test_lru_map
(./test_lru_map >> $OUTPUT 2>&1 && echo "ok 1..4 selftests: bpf: test_lru_map [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..4 selftests: bpf: test_lru_map [SKIP]"; else echo "not ok 1..4 selftests: bpf: test_lru_map [FAIL]"; fi;)
echo selftests: bpf: test_lpm_map
(./test_lpm_map >> $OUTPUT 2>&1 && echo "ok 1..5 selftests: bpf: test_lpm_map [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..5 selftests: bpf: test_lpm_map [SKIP]"; else echo "not ok 1..5 selftests: bpf: test_lpm_map [FAIL]"; fi;)
echo selftests: bpf: test_progs
(./test_progs >> $OUTPUT 2>&1 && echo "ok 1..6 selftests: bpf: test_progs [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..6 selftests: bpf: test_progs [SKIP]"; else echo "not ok 1..6 selftests: bpf: test_progs [FAIL]"; fi;)
echo selftests: bpf: test_align
(./test_align >> $OUTPUT 2>&1 && echo "ok 1..7 selftests: bpf: test_align [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..7 selftests: bpf: test_align [SKIP]"; else echo "not ok 1..7 selftests: bpf: test_align [FAIL]"; fi;)
echo selftests: bpf: test_verifier_log
(./test_verifier_log >> $OUTPUT 2>&1 && echo "ok 1..8 selftests: bpf: test_verifier_log [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..8 selftests: bpf: test_verifier_log [SKIP]"; else echo "not ok 1..8 selftests: bpf: test_verifier_log [FAIL]"; fi;)
echo selftests: bpf: test_dev_cgroup
(./test_dev_cgroup >> $OUTPUT 2>&1 && echo "ok 1..9 selftests: bpf: test_dev_cgroup [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..9 selftests: bpf: test_dev_cgroup [SKIP]"; else echo "not ok 1..9 selftests: bpf: test_dev_cgroup [FAIL]"; fi;)
echo selftests: bpf: test_tcpbpf_user
(./test_tcpbpf_user >> $OUTPUT 2>&1 && echo "ok 1..10 selftests: bpf: test_tcpbpf_user [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..10 selftests: bpf: test_tcpbpf_user [SKIP]"; else echo "not ok 1..10 selftests: bpf: test_tcpbpf_user [FAIL]"; fi;)
echo selftests: bpf: test_sock
(./test_sock >> $OUTPUT 2>&1 && echo "ok 1..11 selftests: bpf: test_sock [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..11 selftests: bpf: test_sock [SKIP]"; else echo "not ok 1..11 selftests: bpf: test_sock [FAIL]"; fi;)
echo selftests: bpf: test_btf
(./test_btf >> $OUTPUT 2>&1 && echo "ok 1..12 selftests: bpf: test_btf [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..12 selftests: bpf: test_btf [SKIP]"; else echo "not ok 1..12 selftests: bpf: test_btf [FAIL]"; fi;)
echo selftests: bpf: test_sockmap
(./test_sockmap >> $OUTPUT 2>&1 && echo "ok 1..13 selftests: bpf: test_sockmap [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..13 selftests: bpf: test_sockmap [SKIP]"; else echo "not ok 1..13 selftests: bpf: test_sockmap [FAIL]"; fi;)
echo selftests: bpf: test_lirc_mode2_user
(./test_lirc_mode2_user >> $OUTPUT 2>&1 && echo "ok 1..14 selftests: bpf: test_lirc_mode2_user [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..14 selftests: bpf: test_lirc_mode2_user [SKIP]"; else echo "not ok 1..14 selftests: bpf: test_lirc_mode2_user [FAIL]"; fi;)
echo selftests: bpf: get_cgroup_id_user
(./get_cgroup_id_user >> $OUTPUT 2>&1 && echo "ok 1..15 selftests: bpf: get_cgroup_id_user [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..15 selftests: bpf: get_cgroup_id_user [SKIP]"; else echo "not ok 1..15 selftests: bpf: get_cgroup_id_user [FAIL]"; fi;)
echo selftests: bpf: test_socket_cookie
(./test_socket_cookie >> $OUTPUT 2>&1 && echo "ok 1..16 selftests: bpf: test_socket_cookie [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..16 selftests: bpf: test_socket_cookie [SKIP]"; else echo "not ok 1..16 selftests: bpf: test_socket_cookie [FAIL]"; fi;)
echo selftests: bpf: test_cgroup_storage
(./test_cgroup_storage >> $OUTPUT 2>&1 && echo "ok 1..17 selftests: bpf: test_cgroup_storage [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..17 selftests: bpf: test_cgroup_storage [SKIP]"; else echo "not ok 1..17 selftests: bpf: test_cgroup_storage [FAIL]"; fi;)
echo selftests: bpf: test_select_reuseport
(./test_select_reuseport >> $OUTPUT 2>&1 && echo "ok 1..18 selftests: bpf: test_select_reuseport [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..18 selftests: bpf: test_select_reuseport [SKIP]"; else echo "not ok 1..18 selftests: bpf: test_select_reuseport [FAIL]"; fi;)
echo selftests: bpf: test_section_names
(./test_section_names >> $OUTPUT 2>&1 && echo "ok 1..19 selftests: bpf: test_section_names [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..19 selftests: bpf: test_section_names [SKIP]"; else echo "not ok 1..19 selftests: bpf: test_section_names [FAIL]"; fi;)
echo selftests: bpf: test_netcnt
(./test_netcnt >> $OUTPUT 2>&1 && echo "ok 1..20 selftests: bpf: test_netcnt [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..20 selftests: bpf: test_netcnt [SKIP]"; else echo "not ok 1..20 selftests: bpf: test_netcnt [FAIL]"; fi;)
echo selftests: bpf: urandom_read
(./urandom_read >> $OUTPUT 2>&1 && echo "ok 1..21 selftests: bpf: urandom_read [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..21 selftests: bpf: urandom_read [SKIP]"; else echo "not ok 1..21 selftests: bpf: urandom_read [FAIL]"; fi;)
echo selftests: bpf: test_kmod.sh
(./test_kmod.sh >> $OUTPUT 2>&1 && echo "ok 1..22 selftests: bpf: test_kmod.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..22 selftests: bpf: test_kmod.sh [SKIP]"; else echo "not ok 1..22 selftests: bpf: test_kmod.sh [FAIL]"; fi;)
echo selftests: bpf: test_libbpf.sh
(./test_libbpf.sh >> $OUTPUT 2>&1 && echo "ok 1..23 selftests: bpf: test_libbpf.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..23 selftests: bpf: test_libbpf.sh [SKIP]"; else echo "not ok 1..23 selftests: bpf: test_libbpf.sh [FAIL]"; fi;)
echo selftests: bpf: test_xdp_redirect.sh
(./test_xdp_redirect.sh >> $OUTPUT 2>&1 && echo "ok 1..24 selftests: bpf: test_xdp_redirect.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..24 selftests: bpf: test_xdp_redirect.sh [SKIP]"; else echo "not ok 1..24 selftests: bpf: test_xdp_redirect.sh [FAIL]"; fi;)
echo selftests: bpf: test_xdp_meta.sh
(./test_xdp_meta.sh >> $OUTPUT 2>&1 && echo "ok 1..25 selftests: bpf: test_xdp_meta.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..25 selftests: bpf: test_xdp_meta.sh [SKIP]"; else echo "not ok 1..25 selftests: bpf: test_xdp_meta.sh [FAIL]"; fi;)
echo selftests: bpf: test_offload.py
(./test_offload.py >> $OUTPUT 2>&1 && echo "ok 1..26 selftests: bpf: test_offload.py [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..26 selftests: bpf: test_offload.py [SKIP]"; else echo "not ok 1..26 selftests: bpf: test_offload.py [FAIL]"; fi;)
echo selftests: bpf: test_sock_addr.sh
(./test_sock_addr.sh >> $OUTPUT 2>&1 && echo "ok 1..27 selftests: bpf: test_sock_addr.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..27 selftests: bpf: test_sock_addr.sh [SKIP]"; else echo "not ok 1..27 selftests: bpf: test_sock_addr.sh [FAIL]"; fi;)
echo selftests: bpf: test_tunnel.sh
(./test_tunnel.sh >> $OUTPUT 2>&1 && echo "ok 1..28 selftests: bpf: test_tunnel.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..28 selftests: bpf: test_tunnel.sh [SKIP]"; else echo "not ok 1..28 selftests: bpf: test_tunnel.sh [FAIL]"; fi;)
echo selftests: bpf: test_lwt_seg6local.sh
(./test_lwt_seg6local.sh >> $OUTPUT 2>&1 && echo "ok 1..29 selftests: bpf: test_lwt_seg6local.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..29 selftests: bpf: test_lwt_seg6local.sh [SKIP]"; else echo "not ok 1..29 selftests: bpf: test_lwt_seg6local.sh [FAIL]"; fi;)
echo selftests: bpf: test_lirc_mode2.sh
(./test_lirc_mode2.sh >> $OUTPUT 2>&1 && echo "ok 1..30 selftests: bpf: test_lirc_mode2.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..30 selftests: bpf: test_lirc_mode2.sh [SKIP]"; else echo "not ok 1..30 selftests: bpf: test_lirc_mode2.sh [FAIL]"; fi;)
echo selftests: bpf: test_skb_cgroup_id.sh
(./test_skb_cgroup_id.sh >> $OUTPUT 2>&1 && echo "ok 1..31 selftests: bpf: test_skb_cgroup_id.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..31 selftests: bpf: test_skb_cgroup_id.sh [SKIP]"; else echo "not ok 1..31 selftests: bpf: test_skb_cgroup_id.sh [FAIL]"; fi;)
echo selftests: bpf: test_flow_dissector.sh
(./test_flow_dissector.sh >> $OUTPUT 2>&1 && echo "ok 1..32 selftests: bpf: test_flow_dissector.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..32 selftests: bpf: test_flow_dissector.sh [SKIP]"; else echo "not ok 1..32 selftests: bpf: test_flow_dissector.sh [FAIL]"; fi;)
echo selftests: bpf: test_xdp_vlan.sh
(./test_xdp_vlan.sh >> $OUTPUT 2>&1 && echo "ok 1..33 selftests: bpf: test_xdp_vlan.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..33 selftests: bpf: test_xdp_vlan.sh [SKIP]"; else echo "not ok 1..33 selftests: bpf: test_xdp_vlan.sh [FAIL]"; fi;)
cd $ROOT
