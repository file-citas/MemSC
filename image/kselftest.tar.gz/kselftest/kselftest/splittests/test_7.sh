#!/bin/sh
BASE_DIR=$(realpath $(dirname $0))
cd $BASE_DIR
ROOT=$PWD
if [ "$1" = "--summary" ]; then
  OUTPUT=$BASE_DIR/output.log
  cat /dev/null > $OUTPUT
else
  OUTPUT=/dev/stdout
fi
export KSFT_TAP_LEVEL=1
export skip=4
cd $ROOT
echo ; echo TAP version 13
echo Running tests in rseq
echo ========================================
[ -w /dev/kmsg ] && echo "kselftest: Running tests in rseq" >> /dev/kmsg
cd rseq
echo selftests: rseq: basic_test
(./basic_test >> $OUTPUT 2>&1 && echo "ok 1..1 selftests: rseq: basic_test [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..1 selftests: rseq: basic_test [SKIP]"; else echo "not ok 1..1 selftests: rseq: basic_test [FAIL]"; fi;)
echo selftests: rseq: basic_percpu_ops_test
(./basic_percpu_ops_test >> $OUTPUT 2>&1 && echo "ok 1..2 selftests: rseq: basic_percpu_ops_test [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..2 selftests: rseq: basic_percpu_ops_test [SKIP]"; else echo "not ok 1..2 selftests: rseq: basic_percpu_ops_test [FAIL]"; fi;)
echo selftests: rseq: param_test
echo "selftests: rseq: param_test: Warning: file param_test is not executable, correct this."
echo "not ok 1..3 selftests: rseq: param_test [FAIL]"
echo selftests: rseq: param_test_benchmark
echo "selftests: rseq: param_test_benchmark: Warning: file param_test_benchmark is not executable, correct this."
echo "not ok 1..4 selftests: rseq: param_test_benchmark [FAIL]"
echo selftests: rseq: param_test_compare_twice
echo "selftests: rseq: param_test_compare_twice: Warning: file param_test_compare_twice is not executable, correct this."
echo "not ok 1..5 selftests: rseq: param_test_compare_twice [FAIL]"
echo selftests: rseq: run_param_test.sh
(./run_param_test.sh >> $OUTPUT 2>&1 && echo "ok 1..6 selftests: rseq: run_param_test.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..6 selftests: rseq: run_param_test.sh [SKIP]"; else echo "not ok 1..6 selftests: rseq: run_param_test.sh [FAIL]"; fi;)
cd $ROOT
