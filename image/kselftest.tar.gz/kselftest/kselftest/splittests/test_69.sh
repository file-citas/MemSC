#!/bin/sh
BASE_DIR=$(realpath $(dirname $0))
cd $BASE_DIR
ROOT=$PWD
if [ "$1" = "--summary" ]; then
  OUTPUT=$BASE_DIR/output.log
  cat /dev/null > $OUTPUT
else
  OUTPUT=/dev/stdout
fi
export KSFT_TAP_LEVEL=1
export skip=4
cd $ROOT
echo ; echo TAP version 13
echo Running tests in x86
echo ========================================
[ -w /dev/kmsg ] && echo "kselftest: Running tests in x86" >> /dev/kmsg
cd x86
#echo selftests: x86: single_step_syscall_32
#(./single_step_syscall_32 >> $OUTPUT 2>&1 && echo "ok 1..1 selftests: x86: single_step_syscall_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..1 selftests: x86: single_step_syscall_32 [SKIP]"; else echo "not ok 1..1 selftests: x86: single_step_syscall_32 [FAIL]"; fi;)
#echo selftests: x86: sysret_ss_attrs_32
#(./sysret_ss_attrs_32 >> $OUTPUT 2>&1 && echo "ok 1..2 selftests: x86: sysret_ss_attrs_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..2 selftests: x86: sysret_ss_attrs_32 [SKIP]"; else echo "not ok 1..2 selftests: x86: sysret_ss_attrs_32 [FAIL]"; fi;)
#echo selftests: x86: syscall_nt_32
#(./syscall_nt_32 >> $OUTPUT 2>&1 && echo "ok 1..3 selftests: x86: syscall_nt_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..3 selftests: x86: syscall_nt_32 [SKIP]"; else echo "not ok 1..3 selftests: x86: syscall_nt_32 [FAIL]"; fi;)
#echo selftests: x86: test_mremap_vdso_32
#(./test_mremap_vdso_32 >> $OUTPUT 2>&1 && echo "ok 1..4 selftests: x86: test_mremap_vdso_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..4 selftests: x86: test_mremap_vdso_32 [SKIP]"; else echo "not ok 1..4 selftests: x86: test_mremap_vdso_32 [FAIL]"; fi;)
#echo selftests: x86: check_initial_reg_state_32
#(./check_initial_reg_state_32 >> $OUTPUT 2>&1 && echo "ok 1..5 selftests: x86: check_initial_reg_state_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..5 selftests: x86: check_initial_reg_state_32 [SKIP]"; else echo "not ok 1..5 selftests: x86: check_initial_reg_state_32 [FAIL]"; fi;)
#echo selftests: x86: sigreturn_32
#(./sigreturn_32 >> $OUTPUT 2>&1 && echo "ok 1..6 selftests: x86: sigreturn_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..6 selftests: x86: sigreturn_32 [SKIP]"; else echo "not ok 1..6 selftests: x86: sigreturn_32 [FAIL]"; fi;)
#echo selftests: x86: iopl_32
#(./iopl_32 >> $OUTPUT 2>&1 && echo "ok 1..7 selftests: x86: iopl_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..7 selftests: x86: iopl_32 [SKIP]"; else echo "not ok 1..7 selftests: x86: iopl_32 [FAIL]"; fi;)
#echo selftests: x86: mpx-mini-test_32
#(./mpx-mini-test_32 >> $OUTPUT 2>&1 && echo "ok 1..8 selftests: x86: mpx-mini-test_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..8 selftests: x86: mpx-mini-test_32 [SKIP]"; else echo "not ok 1..8 selftests: x86: mpx-mini-test_32 [FAIL]"; fi;)
#echo selftests: x86: ioperm_32
#(./ioperm_32 >> $OUTPUT 2>&1 && echo "ok 1..9 selftests: x86: ioperm_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..9 selftests: x86: ioperm_32 [SKIP]"; else echo "not ok 1..9 selftests: x86: ioperm_32 [FAIL]"; fi;)
#echo selftests: x86: protection_keys_32
#(./protection_keys_32 >> $OUTPUT 2>&1 && echo "ok 1..10 selftests: x86: protection_keys_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..10 selftests: x86: protection_keys_32 [SKIP]"; else echo "not ok 1..10 selftests: x86: protection_keys_32 [FAIL]"; fi;)
#echo selftests: x86: test_vdso_32
#(./test_vdso_32 >> $OUTPUT 2>&1 && echo "ok 1..11 selftests: x86: test_vdso_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..11 selftests: x86: test_vdso_32 [SKIP]"; else echo "not ok 1..11 selftests: x86: test_vdso_32 [FAIL]"; fi;)
#echo selftests: x86: test_vsyscall_32
#(./test_vsyscall_32 >> $OUTPUT 2>&1 && echo "ok 1..12 selftests: x86: test_vsyscall_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..12 selftests: x86: test_vsyscall_32 [SKIP]"; else echo "not ok 1..12 selftests: x86: test_vsyscall_32 [FAIL]"; fi;)
#echo selftests: x86: mov_ss_trap_32
#(./mov_ss_trap_32 >> $OUTPUT 2>&1 && echo "ok 1..13 selftests: x86: mov_ss_trap_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..13 selftests: x86: mov_ss_trap_32 [SKIP]"; else echo "not ok 1..13 selftests: x86: mov_ss_trap_32 [FAIL]"; fi;)
#echo selftests: x86: entry_from_vm86_32
#(./entry_from_vm86_32 >> $OUTPUT 2>&1 && echo "ok 1..14 selftests: x86: entry_from_vm86_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..14 selftests: x86: entry_from_vm86_32 [SKIP]"; else echo "not ok 1..14 selftests: x86: entry_from_vm86_32 [FAIL]"; fi;)
#echo selftests: x86: syscall_arg_fault_32
#(./syscall_arg_fault_32 >> $OUTPUT 2>&1 && echo "ok 1..15 selftests: x86: syscall_arg_fault_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..15 selftests: x86: syscall_arg_fault_32 [SKIP]"; else echo "not ok 1..15 selftests: x86: syscall_arg_fault_32 [FAIL]"; fi;)
#echo selftests: x86: test_syscall_vdso_32
#(./test_syscall_vdso_32 >> $OUTPUT 2>&1 && echo "ok 1..16 selftests: x86: test_syscall_vdso_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..16 selftests: x86: test_syscall_vdso_32 [SKIP]"; else echo "not ok 1..16 selftests: x86: test_syscall_vdso_32 [FAIL]"; fi;)
#echo selftests: x86: unwind_vdso_32
#(./unwind_vdso_32 >> $OUTPUT 2>&1 && echo "ok 1..17 selftests: x86: unwind_vdso_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..17 selftests: x86: unwind_vdso_32 [SKIP]"; else echo "not ok 1..17 selftests: x86: unwind_vdso_32 [FAIL]"; fi;)
#echo selftests: x86: test_FCMOV_32
#(./test_FCMOV_32 >> $OUTPUT 2>&1 && echo "ok 1..18 selftests: x86: test_FCMOV_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..18 selftests: x86: test_FCMOV_32 [SKIP]"; else echo "not ok 1..18 selftests: x86: test_FCMOV_32 [FAIL]"; fi;)
#echo selftests: x86: test_FCOMI_32
#(./test_FCOMI_32 >> $OUTPUT 2>&1 && echo "ok 1..19 selftests: x86: test_FCOMI_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..19 selftests: x86: test_FCOMI_32 [SKIP]"; else echo "not ok 1..19 selftests: x86: test_FCOMI_32 [FAIL]"; fi;)
#echo selftests: x86: test_FISTTP_32
#(./test_FISTTP_32 >> $OUTPUT 2>&1 && echo "ok 1..20 selftests: x86: test_FISTTP_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..20 selftests: x86: test_FISTTP_32 [SKIP]"; else echo "not ok 1..20 selftests: x86: test_FISTTP_32 [FAIL]"; fi;)
#echo selftests: x86: vdso_restorer_32
#(./vdso_restorer_32 >> $OUTPUT 2>&1 && echo "ok 1..21 selftests: x86: vdso_restorer_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..21 selftests: x86: vdso_restorer_32 [SKIP]"; else echo "not ok 1..21 selftests: x86: vdso_restorer_32 [FAIL]"; fi;)
#echo selftests: x86: ldt_gdt_32
#(./ldt_gdt_32 >> $OUTPUT 2>&1 && echo "ok 1..22 selftests: x86: ldt_gdt_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..22 selftests: x86: ldt_gdt_32 [SKIP]"; else echo "not ok 1..22 selftests: x86: ldt_gdt_32 [FAIL]"; fi;)
#echo selftests: x86: ptrace_syscall_32
#(./ptrace_syscall_32 >> $OUTPUT 2>&1 && echo "ok 1..23 selftests: x86: ptrace_syscall_32 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..23 selftests: x86: ptrace_syscall_32 [SKIP]"; else echo "not ok 1..23 selftests: x86: ptrace_syscall_32 [FAIL]"; fi;)
#echo selftests: x86: single_step_syscall_64
#(./single_step_syscall_64 >> $OUTPUT 2>&1 && echo "ok 1..24 selftests: x86: single_step_syscall_64 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..24 selftests: x86: single_step_syscall_64 [SKIP]"; else echo "not ok 1..24 selftests: x86: single_step_syscall_64 [FAIL]"; fi;)
#echo selftests: x86: sysret_ss_attrs_64
#(./sysret_ss_attrs_64 >> $OUTPUT 2>&1 && echo "ok 1..25 selftests: x86: sysret_ss_attrs_64 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..25 selftests: x86: sysret_ss_attrs_64 [SKIP]"; else echo "not ok 1..25 selftests: x86: sysret_ss_attrs_64 [FAIL]"; fi;)
#echo selftests: x86: syscall_nt_64
#(./syscall_nt_64 >> $OUTPUT 2>&1 && echo "ok 1..26 selftests: x86: syscall_nt_64 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..26 selftests: x86: syscall_nt_64 [SKIP]"; else echo "not ok 1..26 selftests: x86: syscall_nt_64 [FAIL]"; fi;)
echo selftests: x86: test_mremap_vdso_64
(./test_mremap_vdso_64 >> $OUTPUT 2>&1 && echo "ok 1..27 selftests: x86: test_mremap_vdso_64 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..27 selftests: x86: test_mremap_vdso_64 [SKIP]"; else echo "not ok 1..27 selftests: x86: test_mremap_vdso_64 [FAIL]"; fi;)
#echo selftests: x86: check_initial_reg_state_64
#(./check_initial_reg_state_64 >> $OUTPUT 2>&1 && echo "ok 1..28 selftests: x86: check_initial_reg_state_64 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..28 selftests: x86: check_initial_reg_state_64 [SKIP]"; else echo "not ok 1..28 selftests: x86: check_initial_reg_state_64 [FAIL]"; fi;)
#echo selftests: x86: sigreturn_64
#(./sigreturn_64 >> $OUTPUT 2>&1 && echo "ok 1..29 selftests: x86: sigreturn_64 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..29 selftests: x86: sigreturn_64 [SKIP]"; else echo "not ok 1..29 selftests: x86: sigreturn_64 [FAIL]"; fi;)
#echo selftests: x86: iopl_64
#(./iopl_64 >> $OUTPUT 2>&1 && echo "ok 1..30 selftests: x86: iopl_64 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..30 selftests: x86: iopl_64 [SKIP]"; else echo "not ok 1..30 selftests: x86: iopl_64 [FAIL]"; fi;)
#echo selftests: x86: mpx-mini-test_64
#(./mpx-mini-test_64 >> $OUTPUT 2>&1 && echo "ok 1..31 selftests: x86: mpx-mini-test_64 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..31 selftests: x86: mpx-mini-test_64 [SKIP]"; else echo "not ok 1..31 selftests: x86: mpx-mini-test_64 [FAIL]"; fi;)
#echo selftests: x86: ioperm_64
#(./ioperm_64 >> $OUTPUT 2>&1 && echo "ok 1..32 selftests: x86: ioperm_64 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..32 selftests: x86: ioperm_64 [SKIP]"; else echo "not ok 1..32 selftests: x86: ioperm_64 [FAIL]"; fi;)
#echo selftests: x86: protection_keys_64
#(./protection_keys_64 >> $OUTPUT 2>&1 && echo "ok 1..33 selftests: x86: protection_keys_64 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..33 selftests: x86: protection_keys_64 [SKIP]"; else echo "not ok 1..33 selftests: x86: protection_keys_64 [FAIL]"; fi;)
#echo selftests: x86: test_vdso_64
#(./test_vdso_64 >> $OUTPUT 2>&1 && echo "ok 1..34 selftests: x86: test_vdso_64 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..34 selftests: x86: test_vdso_64 [SKIP]"; else echo "not ok 1..34 selftests: x86: test_vdso_64 [FAIL]"; fi;)
#echo selftests: x86: test_vsyscall_64
#(./test_vsyscall_64 >> $OUTPUT 2>&1 && echo "ok 1..35 selftests: x86: test_vsyscall_64 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..35 selftests: x86: test_vsyscall_64 [SKIP]"; else echo "not ok 1..35 selftests: x86: test_vsyscall_64 [FAIL]"; fi;)
#echo selftests: x86: mov_ss_trap_64
#(./mov_ss_trap_64 >> $OUTPUT 2>&1 && echo "ok 1..36 selftests: x86: mov_ss_trap_64 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..36 selftests: x86: mov_ss_trap_64 [SKIP]"; else echo "not ok 1..36 selftests: x86: mov_ss_trap_64 [FAIL]"; fi;)
#echo selftests: x86: fsgsbase_64
#(./fsgsbase_64 >> $OUTPUT 2>&1 && echo "ok 1..37 selftests: x86: fsgsbase_64 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..37 selftests: x86: fsgsbase_64 [SKIP]"; else echo "not ok 1..37 selftests: x86: fsgsbase_64 [FAIL]"; fi;)
#echo selftests: x86: sysret_rip_64
#(./sysret_rip_64 >> $OUTPUT 2>&1 && echo "ok 1..38 selftests: x86: sysret_rip_64 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..38 selftests: x86: sysret_rip_64 [SKIP]"; else echo "not ok 1..38 selftests: x86: sysret_rip_64 [FAIL]"; fi;)
#echo selftests: x86: ldt_gdt_64
#(./ldt_gdt_64 >> $OUTPUT 2>&1 && echo "ok 1..39 selftests: x86: ldt_gdt_64 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..39 selftests: x86: ldt_gdt_64 [SKIP]"; else echo "not ok 1..39 selftests: x86: ldt_gdt_64 [FAIL]"; fi;)
#echo selftests: x86: ptrace_syscall_64
#(./ptrace_syscall_64 >> $OUTPUT 2>&1 && echo "ok 1..40 selftests: x86: ptrace_syscall_64 [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..40 selftests: x86: ptrace_syscall_64 [SKIP]"; else echo "not ok 1..40 selftests: x86: ptrace_syscall_64 [FAIL]"; fi;)
cd $ROOT
