#!/bin/sh
BASE_DIR=$(realpath $(dirname $0))
cd $BASE_DIR
ROOT=$PWD
if [ "$1" = "--summary" ]; then
  OUTPUT=$BASE_DIR/output.log
  cat /dev/null > $OUTPUT
else
  OUTPUT=/dev/stdout
fi
export KSFT_TAP_LEVEL=1
export skip=4
cd $ROOT
echo ; echo TAP version 13
echo Running tests in net
echo ========================================
[ -w /dev/kmsg ] && echo "kselftest: Running tests in net" >> /dev/kmsg
cd net
echo selftests: net: reuseport_bpf
(./reuseport_bpf >> $OUTPUT 2>&1 && echo "ok 1..1 selftests: net: reuseport_bpf [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..1 selftests: net: reuseport_bpf [SKIP]"; else echo "not ok 1..1 selftests: net: reuseport_bpf [FAIL]"; fi;)
echo selftests: net: reuseport_bpf_cpu
(./reuseport_bpf_cpu >> $OUTPUT 2>&1 && echo "ok 1..2 selftests: net: reuseport_bpf_cpu [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..2 selftests: net: reuseport_bpf_cpu [SKIP]"; else echo "not ok 1..2 selftests: net: reuseport_bpf_cpu [FAIL]"; fi;)
echo selftests: net: reuseport_bpf_numa
(./reuseport_bpf_numa >> $OUTPUT 2>&1 && echo "ok 1..3 selftests: net: reuseport_bpf_numa [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..3 selftests: net: reuseport_bpf_numa [SKIP]"; else echo "not ok 1..3 selftests: net: reuseport_bpf_numa [FAIL]"; fi;)
echo selftests: net: reuseport_dualstack
(./reuseport_dualstack >> $OUTPUT 2>&1 && echo "ok 1..4 selftests: net: reuseport_dualstack [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..4 selftests: net: reuseport_dualstack [SKIP]"; else echo "not ok 1..4 selftests: net: reuseport_dualstack [FAIL]"; fi;)
echo selftests: net: reuseaddr_conflict
(./reuseaddr_conflict >> $OUTPUT 2>&1 && echo "ok 1..5 selftests: net: reuseaddr_conflict [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..5 selftests: net: reuseaddr_conflict [SKIP]"; else echo "not ok 1..5 selftests: net: reuseaddr_conflict [FAIL]"; fi;)
echo selftests: net: tls
(./tls >> $OUTPUT 2>&1 && echo "ok 1..6 selftests: net: tls [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..6 selftests: net: tls [SKIP]"; else echo "not ok 1..6 selftests: net: tls [FAIL]"; fi;)
echo selftests: net: run_netsocktests
(./run_netsocktests >> $OUTPUT 2>&1 && echo "ok 1..7 selftests: net: run_netsocktests [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..7 selftests: net: run_netsocktests [SKIP]"; else echo "not ok 1..7 selftests: net: run_netsocktests [FAIL]"; fi;)
echo selftests: net: run_afpackettests
(./run_afpackettests >> $OUTPUT 2>&1 && echo "ok 1..8 selftests: net: run_afpackettests [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..8 selftests: net: run_afpackettests [SKIP]"; else echo "not ok 1..8 selftests: net: run_afpackettests [FAIL]"; fi;)
echo selftests: net: test_bpf.sh
(./test_bpf.sh >> $OUTPUT 2>&1 && echo "ok 1..9 selftests: net: test_bpf.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..9 selftests: net: test_bpf.sh [SKIP]"; else echo "not ok 1..9 selftests: net: test_bpf.sh [FAIL]"; fi;)
echo selftests: net: netdevice.sh
(./netdevice.sh >> $OUTPUT 2>&1 && echo "ok 1..10 selftests: net: netdevice.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..10 selftests: net: netdevice.sh [SKIP]"; else echo "not ok 1..10 selftests: net: netdevice.sh [FAIL]"; fi;)
echo selftests: net: rtnetlink.sh
(./rtnetlink.sh >> $OUTPUT 2>&1 && echo "ok 1..11 selftests: net: rtnetlink.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..11 selftests: net: rtnetlink.sh [SKIP]"; else echo "not ok 1..11 selftests: net: rtnetlink.sh [FAIL]"; fi;)
echo selftests: net: fib_tests.sh
(./fib_tests.sh >> $OUTPUT 2>&1 && echo "ok 1..12 selftests: net: fib_tests.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..12 selftests: net: fib_tests.sh [SKIP]"; else echo "not ok 1..12 selftests: net: fib_tests.sh [FAIL]"; fi;)
echo selftests: net: fib-onlink-tests.sh
(./fib-onlink-tests.sh >> $OUTPUT 2>&1 && echo "ok 1..13 selftests: net: fib-onlink-tests.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..13 selftests: net: fib-onlink-tests.sh [SKIP]"; else echo "not ok 1..13 selftests: net: fib-onlink-tests.sh [FAIL]"; fi;)
echo selftests: net: pmtu.sh
(./pmtu.sh >> $OUTPUT 2>&1 && echo "ok 1..14 selftests: net: pmtu.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..14 selftests: net: pmtu.sh [SKIP]"; else echo "not ok 1..14 selftests: net: pmtu.sh [FAIL]"; fi;)
echo selftests: net: udpgso.sh
(./udpgso.sh >> $OUTPUT 2>&1 && echo "ok 1..15 selftests: net: udpgso.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..15 selftests: net: udpgso.sh [SKIP]"; else echo "not ok 1..15 selftests: net: udpgso.sh [FAIL]"; fi;)
echo selftests: net: ip_defrag.sh
(./ip_defrag.sh >> $OUTPUT 2>&1 && echo "ok 1..16 selftests: net: ip_defrag.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..16 selftests: net: ip_defrag.sh [SKIP]"; else echo "not ok 1..16 selftests: net: ip_defrag.sh [FAIL]"; fi;)
echo selftests: net: udpgso_bench.sh
(./udpgso_bench.sh >> $OUTPUT 2>&1 && echo "ok 1..17 selftests: net: udpgso_bench.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..17 selftests: net: udpgso_bench.sh [SKIP]"; else echo "not ok 1..17 selftests: net: udpgso_bench.sh [FAIL]"; fi;)
echo selftests: net: fib_rule_tests.sh
(./fib_rule_tests.sh >> $OUTPUT 2>&1 && echo "ok 1..18 selftests: net: fib_rule_tests.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..18 selftests: net: fib_rule_tests.sh [SKIP]"; else echo "not ok 1..18 selftests: net: fib_rule_tests.sh [FAIL]"; fi;)
echo selftests: net: msg_zerocopy.sh
(./msg_zerocopy.sh >> $OUTPUT 2>&1 && echo "ok 1..19 selftests: net: msg_zerocopy.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..19 selftests: net: msg_zerocopy.sh [SKIP]"; else echo "not ok 1..19 selftests: net: msg_zerocopy.sh [FAIL]"; fi;)
echo selftests: net: psock_snd.sh
(./psock_snd.sh >> $OUTPUT 2>&1 && echo "ok 1..20 selftests: net: psock_snd.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..20 selftests: net: psock_snd.sh [SKIP]"; else echo "not ok 1..20 selftests: net: psock_snd.sh [FAIL]"; fi;)
echo selftests: net: test_vxlan_fdb_changelink.sh
(./test_vxlan_fdb_changelink.sh >> $OUTPUT 2>&1 && echo "ok 1..21 selftests: net: test_vxlan_fdb_changelink.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..21 selftests: net: test_vxlan_fdb_changelink.sh [SKIP]"; else echo "not ok 1..21 selftests: net: test_vxlan_fdb_changelink.sh [FAIL]"; fi;)
cd $ROOT
