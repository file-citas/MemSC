#!/bin/sh
BASE_DIR=$(realpath $(dirname $0))
cd $BASE_DIR
ROOT=$PWD
if [ "$1" = "--summary" ]; then
  OUTPUT=$BASE_DIR/output.log
  cat /dev/null > $OUTPUT
else
  OUTPUT=/dev/stdout
fi
export KSFT_TAP_LEVEL=1
export skip=4
cd $ROOT
echo ; echo TAP version 13
echo Running tests in nsfs
echo ========================================
[ -w /dev/kmsg ] && echo "kselftest: Running tests in nsfs" >> /dev/kmsg
cd nsfs
echo selftests: nsfs: owner
(./owner >> $OUTPUT 2>&1 && echo "ok 1..1 selftests: nsfs: owner [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..1 selftests: nsfs: owner [SKIP]"; else echo "not ok 1..1 selftests: nsfs: owner [FAIL]"; fi;)
echo selftests: nsfs: pidns
(./pidns >> $OUTPUT 2>&1 && echo "ok 1..2 selftests: nsfs: pidns [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..2 selftests: nsfs: pidns [SKIP]"; else echo "not ok 1..2 selftests: nsfs: pidns [FAIL]"; fi;)
cd $ROOT
