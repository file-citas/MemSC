#!/bin/sh
BASE_DIR=$(realpath $(dirname $0))
cd $BASE_DIR
ROOT=$PWD
if [ "$1" = "--summary" ]; then
  OUTPUT=$BASE_DIR/output.log
  cat /dev/null > $OUTPUT
else
  OUTPUT=/dev/stdout
fi
export KSFT_TAP_LEVEL=1
export skip=4
cd $ROOT
echo ; echo TAP version 13
echo Running tests in splice
echo ========================================
[ -w /dev/kmsg ] && echo "kselftest: Running tests in splice" >> /dev/kmsg
cd splice
echo selftests: splice: default_file_splice_read.sh
(./default_file_splice_read.sh >> $OUTPUT 2>&1 && echo "ok 1..1 selftests: splice: default_file_splice_read.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..1 selftests: splice: default_file_splice_read.sh [SKIP]"; else echo "not ok 1..1 selftests: splice: default_file_splice_read.sh [FAIL]"; fi;)
cd $ROOT
