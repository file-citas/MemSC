#!/bin/sh
BASE_DIR=$(realpath $(dirname $0))
cd $BASE_DIR
ROOT=$PWD
if [ "$1" = "--summary" ]; then
  OUTPUT=$BASE_DIR/output.log
  cat /dev/null > $OUTPUT
else
  OUTPUT=/dev/stdout
fi
export KSFT_TAP_LEVEL=1
export skip=4
cd $ROOT
echo ; echo TAP version 13
echo Running tests in breakpoints
echo ========================================
[ -w /dev/kmsg ] && echo "kselftest: Running tests in breakpoints" >> /dev/kmsg
cd breakpoints
echo selftests: breakpoints: step_after_suspend_test
(./step_after_suspend_test >> $OUTPUT 2>&1 && echo "ok 1..1 selftests: breakpoints: step_after_suspend_test [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..1 selftests: breakpoints: step_after_suspend_test [SKIP]"; else echo "not ok 1..1 selftests: breakpoints: step_after_suspend_test [FAIL]"; fi;)
echo selftests: breakpoints: breakpoint_test
(./breakpoint_test >> $OUTPUT 2>&1 && echo "ok 1..2 selftests: breakpoints: breakpoint_test [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..2 selftests: breakpoints: breakpoint_test [SKIP]"; else echo "not ok 1..2 selftests: breakpoints: breakpoint_test [FAIL]"; fi;)
cd $ROOT
