#!/bin/sh
BASE_DIR=$(realpath $(dirname $0))
cd $BASE_DIR
ROOT=$PWD
if [ "$1" = "--summary" ]; then
  OUTPUT=$BASE_DIR/output.log
  cat /dev/null > $OUTPUT
else
  OUTPUT=/dev/stdout
fi
export KSFT_TAP_LEVEL=1
export skip=4
echo ; echo TAP version 13
cd $ROOT
echo Running tests in capabilities
echo ========================================
[ -w /dev/kmsg ] && echo "kselftest: Running tests in capabilities" >> /dev/kmsg
cd capabilities
echo selftests: capabilities: test_execve
(./test_execve >> $OUTPUT 2>&1 && echo "ok 1..1 selftests: capabilities: test_execve [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..1 selftests: capabilities: test_execve [SKIP]"; else echo "not ok 1..1 selftests: capabilities: test_execve [FAIL]"; fi;)
cd $ROOT

