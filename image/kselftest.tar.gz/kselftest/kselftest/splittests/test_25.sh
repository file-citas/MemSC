#!/bin/sh
BASE_DIR=$(realpath $(dirname $0))
cd $BASE_DIR
ROOT=$PWD
if [ "$1" = "--summary" ]; then
  OUTPUT=$BASE_DIR/output.log
  cat /dev/null > $OUTPUT
else
  OUTPUT=/dev/stdout
fi
export KSFT_TAP_LEVEL=1
export skip=4
cd $ROOT
echo ; echo TAP version 13
echo Running tests in lib
echo ========================================
[ -w /dev/kmsg ] && echo "kselftest: Running tests in lib" >> /dev/kmsg
cd lib
echo selftests: lib: printf.sh
(./printf.sh >> $OUTPUT 2>&1 && echo "ok 1..1 selftests: lib: printf.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..1 selftests: lib: printf.sh [SKIP]"; else echo "not ok 1..1 selftests: lib: printf.sh [FAIL]"; fi;)
echo selftests: lib: bitmap.sh
(./bitmap.sh >> $OUTPUT 2>&1 && echo "ok 1..2 selftests: lib: bitmap.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..2 selftests: lib: bitmap.sh [SKIP]"; else echo "not ok 1..2 selftests: lib: bitmap.sh [FAIL]"; fi;)
echo selftests: lib: prime_numbers.sh
(./prime_numbers.sh >> $OUTPUT 2>&1 && echo "ok 1..3 selftests: lib: prime_numbers.sh [PASS]") || (if [ $? -eq $skip ]; then echo "not ok 1..3 selftests: lib: prime_numbers.sh [SKIP]"; else echo "not ok 1..3 selftests: lib: prime_numbers.sh [FAIL]"; fi;)
cd $ROOT
