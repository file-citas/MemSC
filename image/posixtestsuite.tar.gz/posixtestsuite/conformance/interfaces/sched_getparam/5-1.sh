#! /bin/sh
#
# Test that sched_getparam() sets errno == ESRCH if the pid cannot be found.
# This is tested implicitly via assertion 4.

echo "Tested implicitly via assertion 4."
exit 0

