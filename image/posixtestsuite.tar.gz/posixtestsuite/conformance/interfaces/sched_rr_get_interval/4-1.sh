#! /bin/sh
#
# Test that sched_rr_get_interval() sets errno == ESRCH if the pid cannot be
# found.
# This is tested implicitly via assertion 3.

echo "Tested implicitly via assertion 3."
exit 0


